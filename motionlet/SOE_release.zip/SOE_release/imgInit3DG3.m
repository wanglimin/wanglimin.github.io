function [G3a_img, G3b_img, G3c_img, G3d_img, G3e_img, G3f_img, G3g_img, G3h_img, G3i_img, G3j_img] = imgInit3DG3(img)
SAMPLING_RATE=0.5;
N=0.184;

syms t;
f1=-4*N*(2*t^3-3*t)*exp(-t^2);
f2=t*exp(-t^2);
f3=-4*N*(2*t^2-1)*exp(-t^2);
f4=exp(-t^2);
f5=-8*N*t*exp(-t^2);

i=SAMPLING_RATE*[-6:6];
filter_size=length(i);
basis=[subs(f1,t,i); subs(f2,t,i); subs(f3,t,i); subs(f4,t,i); subs(f5,t,i)];

G3a_img=imfilter(img,reshape(basis(1,:),1,filter_size),'symmetric','same','conv');
G3a_img=imfilter(G3a_img,reshape(basis(4,:),filter_size,1),'symmetric','same','conv');
G3a_img=imfilter(G3a_img,reshape(basis(4,:),1,1,filter_size),'symmetric','same','conv');

G3b_img=imfilter(img,reshape(basis(3,:),1,filter_size),'symmetric','same','conv');
G3b_img=imfilter(G3b_img,reshape(basis(2,:),filter_size,1),'symmetric','same','conv');
G3b_img=imfilter(G3b_img,reshape(basis(4,:),1,1,filter_size),'symmetric','same','conv');

G3c_img=imfilter(img,reshape(basis(2,:),1,filter_size),'symmetric','same','conv');
G3c_img=imfilter(G3c_img,reshape(basis(3,:),filter_size,1),'symmetric','same','conv');
G3c_img=imfilter(G3c_img,reshape(basis(4,:),1,1,filter_size),'symmetric','same','conv');

G3d_img=imfilter(img,reshape(basis(4,:),1,filter_size),'symmetric','same','conv');
G3d_img=imfilter(G3d_img,reshape(basis(1,:),filter_size,1),'symmetric','same','conv');
G3d_img=imfilter(G3d_img,reshape(basis(4,:),1,1,filter_size),'symmetric','same','conv');

G3e_img=imfilter(img,reshape(basis(3,:),1,filter_size),'symmetric','same','conv');
G3e_img=imfilter(G3e_img,reshape(basis(4,:),filter_size,1),'symmetric','same','conv');
G3e_img=imfilter(G3e_img,reshape(basis(2,:),1,1,filter_size),'symmetric','same','conv');

G3f_img=imfilter(img,reshape(basis(5,:),1,filter_size),'symmetric','same','conv');
G3f_img=imfilter(G3f_img,reshape(basis(2,:),filter_size,1),'symmetric','same','conv');
G3f_img=imfilter(G3f_img,reshape(basis(2,:),1,1,filter_size),'symmetric','same','conv');

G3g_img=imfilter(img,reshape(basis(4,:),1,filter_size),'symmetric','same','conv');
G3g_img=imfilter(G3g_img,reshape(basis(3,:),filter_size,1),'symmetric','same','conv');
G3g_img=imfilter(G3g_img,reshape(basis(2,:),1,1,filter_size),'symmetric','same','conv');

G3h_img=imfilter(img,reshape(basis(2,:),1,filter_size),'symmetric','same','conv');
G3h_img=imfilter(G3h_img,reshape(basis(4,:),filter_size,1),'symmetric','same','conv');
G3h_img=imfilter(G3h_img,reshape(basis(3,:),1,1,filter_size),'symmetric','same','conv');

G3i_img=imfilter(img,reshape(basis(4,:),1,filter_size),'symmetric','same','conv');
G3i_img=imfilter(G3i_img,reshape(basis(2,:),filter_size,1),'symmetric','same','conv');
G3i_img=imfilter(G3i_img,reshape(basis(3,:),1,1,filter_size),'symmetric','same','conv');

G3j_img=imfilter(img,reshape(basis(4,:),1,filter_size),'symmetric','same','conv');
G3j_img=imfilter(G3j_img,reshape(basis(4,:),filter_size,1),'symmetric','same','conv');
G3j_img=imfilter(G3j_img,reshape(basis(1,:),1,1,filter_size),'symmetric','same','conv');