%% Function for calculating dense HOG for video
% vid_x, vid_y: x- and y- gradient for video
% width height length: dense sampling parameter
% nbin: the number of nibin

%%

function [feature]=HOG(vid_x,vid_y,width,height,length,nbin)
[w,h,l]=size(vid_x);

n_w=floor(w/width);
n_h=floor(h/height);
n_l=floor(l/length);

M=sqrt(vid_x.^2+vid_y.^2);
P=atan2(vid_y,vid_x);
P(P<0)=P(P<0)+2*pi;

step=2*pi/nbin;
temp1=floor(P./step)+1;
temp2=temp1+1;

distance1=(P-(temp1-1)*step)./step;
distance2=((temp2-1)*step-P)./step;

distance1=(1-distance1).*M;
distance2=(1-distance2).*M;

feature=zeros(n_w,n_h,n_l,nbin*8);
for i=1:n_w
    for j=1:n_h
        for k=1:n_l
            local1=temp1((i-1)*width+1:i*width,(j-1)*height+1:j*height,(k-1)*length+1:k*length);
            weight1=distance1((i-1)*width+1:i*width,(j-1)*height+1:j*height,(k-1)*length+1:k*length);
            local2=temp2((i-1)*width+1:i*width,(j-1)*height+1:j*height,(k-1)*length+1:k*length);
            weight2=distance2((i-1)*width+1:i*width,(j-1)*height+1:j*height,(k-1)*length+1:k*length);
            count=0;
            for x=1:2
                for y=1:2
                    for z=1:2
                        templocal1=local1((x-1)*width/2+1:x*width/2,(y-1)*height/2+1:y*height/2,(z-1)*length/2+1:z*length/2);
                        tempweight1=weight1((x-1)*width/2+1:x*width/2,(y-1)*height/2+1:y*height/2,(z-1)*length/2+1:z*length/2);
                        templocal2=local2((x-1)*width/2+1:x*width/2,(y-1)*height/2+1:y*height/2,(z-1)*length/2+1:z*length/2);
                        tempweight2=weight2((x-1)*width/2+1:x*width/2,(y-1)*height/2+1:y*height/2,(z-1)*length/2+1:z*length/2);
                        for nb=1:nbin
                            feature(i,j,k,count*nbin+nb)=sum(sum(sum(tempweight1(templocal1==nb))))+sum(sum(sum(tempweight2(templocal2==nb))));
                        end
                        feature(i,j,k,count*nbin+1:(count+1)*nbin)=feature(i,j,k,count*nbin+1:(count+1)*nbin)./(sum(feature(i,j,k,count*nbin+1:(count+1)*nbin))+eps);
                        count=count+1;
                    end
                end
            end
                        
        end
    end
end

end