% IMGSTEER3DG2
%    
%   Steer 3D G2 filter to direction DIRECTION (unit vector) using basis
%   images G2A_IMG, ..., G2F_IMG, computed using IMGINIT3DG2.
%
%   References (available at www.cs.yorku.ca/~kosta): 
%     1. Derpanis, K.G, and Gryn J.M., Three-Dimensional nth Derivative of 
%          Gaussian Separable Steerable Filters, ICIP, 2005
%
%     2. Derpanis, K.G, and Gryn J.M., Three-Dimensional nth Derivative of 
%          Gaussian Separable Steerable Filters, Technical Report CS-2004-05, 
%          York University
%
%   Disclaimer: Note that while great care has been taken, the software, code
%             and data are provided "as is" and that the author does not 
%             accept any responsibility or liability.
%
% Coded By: Konstatinos G. Derpanis
% Last Updated: April 17, 2006.
function [img] = imgSteer3DG2(direction, G2a_img, G2b_img, G2c_img, G2d_img, G2e_img, G2f_img)

a = direction(1);
b = direction(2);
c = direction(3);

img = (a^2)*G2a_img ... 
    + 2*a*b*G2b_img ...
    + (b^2)*G2c_img ...
    + 2*a*c*G2d_img ...
    + 2*b*c*G2e_img ...
    + (c^2)*G2f_img;
    
    