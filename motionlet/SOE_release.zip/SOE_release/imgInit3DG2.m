% IMGINIT3DG2
%    Initialize three-dimensional G2 basis filters, G2A_IMG, ..., G2F_IMG,
%    for image IMG.
%
%   References (available at www.cs.yorku.ca/~kosta): 
%     1. Derpanis, K.G, and Gryn J.M., Three-Dimensional nth Derivative of 
%          Gaussian Separable Steerable Filters, ICIP, 2005
%
%     2. Derpanis, K.G, and Gryn J.M., Three-Dimensional nth Derivative of 
%          Gaussian Separable Steerable Filters, Technical Report CS-2004-05, 
%          York University
%
%   Disclaimer: Note that while great care has been taken, the software, code
%               and data are provided "as is" and that the author does not 
%               accept any responsibility or liability.
%
% Coded By: Konstatinos G. Derpanis
% Last Updated: April 17, 2006.
function [G2a_img, G2b_img, G2c_img, G2d_img, G2e_img, G2f_img] = imgInit3DG2(img)

SAMPLING_RATE = 0.67;
N = (2/sqrt(3))*(2/pi)^(3/4);
syms t;
f1 = N*(2*t^2 - 1)*exp(-t^2); 
f2 = exp(-t^2); 
f3 = 2*N*t*exp(-t^2); 
f4 = t*exp(-t^2);

i = SAMPLING_RATE*[-4:4];
filter_size = length(i);

basis = [subs(f1,t,i); subs(f2,t,i); subs(f3,t,i); subs(f4,t,i)];

G2a_img = imfilter(img, reshape(basis(1,:),1,filter_size),'symmetric','same','conv');   % x-direction
G2a_img = imfilter(G2a_img,reshape(basis(2,:),filter_size,1),'symmetric','same','conv');   % y-direction
G2a_img = imfilter(G2a_img,reshape(basis(2,:),1,1,filter_size),'symmetric','same','conv'); % z-direction

G2b_img = imfilter(img, reshape(basis(3,:),1,filter_size),'symmetric','same','conv');   % x-direction
G2b_img = imfilter(G2b_img,reshape(basis(4,:),filter_size,1),'symmetric','same','conv');   % y-direction
G2b_img = imfilter(G2b_img,reshape(basis(2,:),1,1,filter_size),'symmetric','same','conv'); % z-direction

G2c_img = imfilter(img, reshape(basis(2,:),1,filter_size),'symmetric','same','conv');   % x-direction
G2c_img = imfilter(G2c_img,reshape(basis(1,:),filter_size,1),'symmetric','same','conv');   % y-direction
G2c_img = imfilter(G2c_img,reshape(basis(2,:),1,1,filter_size),'symmetric','same','conv'); % z-direction

G2d_img = imfilter(img, reshape(basis(3,:),1,filter_size),'symmetric','same','conv');   % x-direction
G2d_img = imfilter(G2d_img,reshape(basis(2,:),filter_size,1),'symmetric','same','conv');   % y-direction
G2d_img = imfilter(G2d_img,reshape(basis(4,:),1,1,filter_size),'symmetric','same','conv'); % z-direction

G2e_img = imfilter(img, reshape(basis(2,:),1,filter_size),'symmetric','same','conv');   % x-direction
G2e_img = imfilter(G2e_img,reshape(basis(3,:),filter_size,1),'symmetric','same','conv');   % y-direction
G2e_img = imfilter(G2e_img,reshape(basis(4,:),1,1,filter_size),'symmetric','same','conv'); % z-direction

G2f_img = imfilter(img, reshape(basis(2,:),1,filter_size),'symmetric','same','conv');   % x-direction
G2f_img = imfilter(G2f_img,reshape(basis(2,:),filter_size,1),'symmetric','same','conv');   % y-direction
G2f_img = imfilter(G2f_img,reshape(basis(1,:),1,1,filter_size),'symmetric','same','conv'); % z-direction
