function [hooeImg,hogImg]=VisualFeature(vid,index,bs)
temp=reshape(vid(:,:,index,1:64),size(vid,1),size(vid,2),64);
HOOE=zeros(size(vid,1),size(vid,2),8);
for i=1:1
    HOOE(:,:,:)=HOOE(:,:,:)+temp(:,:,(i-1)*8+1:i*8);
end
HOOE=bsxfun(@rdivide,HOOE(:,:,:),sum(HOOE,3)+eps);
hooeImg=visualizeHistogram(HOOE,bs);

temp=reshape(vid(:,:,index,65:end),size(vid,1),size(vid,2),64);
HOG=zeros(size(vid,1),size(vid,2),8);
for i=1:1
    HOG(:,:,:)=HOG(:,:,:)+temp(:,:,(i-1)*8+1:i*8);
end
HOG=bsxfun(@rdivide,HOG(:,:,:),sum(HOG,3)+eps);
hogImg=visualizeHistogram(HOG,bs);

end