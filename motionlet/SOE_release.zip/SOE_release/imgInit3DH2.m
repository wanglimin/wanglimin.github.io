% IMGINIT3DH2
%    Initialize three-dimensional H2 basis filters, H2A_IMG, ..., H2J_IMG,
%    for image IMG.
%
%   References (available at www.cs.yorku.ca/~kosta): 
%     1. Derpanis, K.G, and Gryn J.M., Three-Dimensional nth Derivative of 
%          Gaussian Separable Steerable Filters, ICIP, 2005
%
%     2. Derpanis, K.G, and Gryn J.M., Three-Dimensional nth Derivative of 
%          Gaussian Separable Steerable Filters, Technical Report CS-2004-05, 
%          York University
%
%   Disclaimer: Note that while great care has been taken, the software, code
%               and data are provided "as is" and that the author does not 
%               accept any responsibility or liability.
%
% Coded By: Konstatinos G. Derpanis
% Last Updated: April 17, 2006.
function [H2a_img, H2b_img, H2c_img, H2d_img, H2e_img, H2f_img, H2g_img, H2h_img, H2i_img, H2j_img] = imgInit3DH2(img)

SAMPLING_RATE = 0.67;
N = 0.877776;
syms t;

f1 = N*(t^3 - 2.254*t)*exp(-t^2); 
f2 = N*(t^2 - 0.751333)*exp(-t^2); 
f3 = exp(-t^2); 
f4 = N*t*exp(-t^2);
f5 = t*exp(-t^2);

i = SAMPLING_RATE*[-4:4];
filter_size = length(i);

basis = [subs(f1,t,i); subs(f2,t,i); subs(f3,t,i); subs(f4,t,i); subs(f5,t,i)];

H2a_img = imfilter(img,    reshape(basis(1,:),1,filter_size),'symmetric','same','conv');   % x-direction
H2a_img = imfilter(H2a_img,reshape(basis(3,:),filter_size,1),'symmetric','same','conv');   % y-direction
H2a_img = imfilter(H2a_img,reshape(basis(3,:),1,1,filter_size),'symmetric','same','conv'); % z-direction

H2b_img = imfilter(img,    reshape(basis(2,:),1,filter_size),'symmetric','same','conv');   % x-direction
H2b_img = imfilter(H2b_img,reshape(basis(5,:),filter_size,1),'symmetric','same','conv');   % y-direction
H2b_img = imfilter(H2b_img,reshape(basis(3,:),1,1,filter_size),'symmetric','same','conv'); % z-direction

H2c_img = imfilter(img,    reshape(basis(5,:),1,filter_size),'symmetric','same','conv');   % x-direction
H2c_img = imfilter(H2c_img,reshape(basis(2,:),filter_size,1),'symmetric','same','conv');   % y-direction
H2c_img = imfilter(H2c_img,reshape(basis(3,:),1,1,filter_size),'symmetric','same','conv'); % z-direction

H2d_img = imfilter(img,    reshape(basis(3,:),1,filter_size),'symmetric','same','conv');   % x-direction
H2d_img = imfilter(H2d_img,reshape(basis(1,:),filter_size,1),'symmetric','same','conv');   % y-direction
H2d_img = imfilter(H2d_img,reshape(basis(3,:),1,1,filter_size),'symmetric','same','conv'); % z-direction

H2e_img = imfilter(img,    reshape(basis(2,:),1,filter_size),'symmetric','same','conv');   % x-direction
H2e_img = imfilter(H2e_img,reshape(basis(3,:),filter_size,1),'symmetric','same','conv');   % y-direction
H2e_img = imfilter(H2e_img,reshape(basis(5,:),1,1,filter_size),'symmetric','same','conv'); % z-direction

H2f_img = imfilter(img,    reshape(basis(4,:),1,filter_size),'symmetric','same','conv');   % x-direction
H2f_img = imfilter(H2f_img,reshape(basis(5,:),filter_size,1),'symmetric','same','conv');   % y-direction
H2f_img = imfilter(H2f_img,reshape(basis(5,:),1,1,filter_size),'symmetric','same','conv'); % z-direction

H2g_img = imfilter(img,    reshape(basis(3,:),1,filter_size),'symmetric','same','conv');   % x-direction
H2g_img = imfilter(H2g_img,reshape(basis(2,:),filter_size,1),'symmetric','same','conv');   % y-direction
H2g_img = imfilter(H2g_img,reshape(basis(5,:),1,1,filter_size),'symmetric','same','conv'); % z-direction

H2h_img = imfilter(img,    reshape(basis(5,:),1,filter_size),'symmetric','same','conv');   % x-direction
H2h_img = imfilter(H2h_img,reshape(basis(3,:),filter_size,1),'symmetric','same','conv');   % y-direction
H2h_img = imfilter(H2h_img,reshape(basis(2,:),1,1,filter_size),'symmetric','same','conv'); % z-direction

H2i_img = imfilter(img,    reshape(basis(3,:),1,filter_size),'symmetric','same','conv');   % x-direction
H2i_img = imfilter(H2i_img,reshape(basis(5,:),filter_size,1),'symmetric','same','conv');   % y-direction
H2i_img = imfilter(H2i_img,reshape(basis(2,:),1,1,filter_size),'symmetric','same','conv'); % z-direction

H2j_img = imfilter(img,    reshape(basis(3,:),1,filter_size),'symmetric','same','conv');   % x-direction
H2j_img = imfilter(H2j_img,reshape(basis(3,:),filter_size,1),'symmetric','same','conv');   % y-direction
H2j_img = imfilter(H2j_img,reshape(basis(1,:),1,1,filter_size),'symmetric','same','conv'); % z-direction
