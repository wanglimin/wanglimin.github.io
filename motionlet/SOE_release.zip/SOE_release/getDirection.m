function direction=getDirection(n_hat,e_axis,i,N)
n_cross=cross(n_hat,e_axis);
theta_na=n_cross./sqrt(sum(n_cross.^2));
theta_nb=cross(n_hat,theta_na);
direction=cos((pi*i)/(N+1))*theta_na+sin((pi*i)/(N+1))*theta_nb;
end