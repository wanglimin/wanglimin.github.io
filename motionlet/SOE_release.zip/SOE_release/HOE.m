function [feature]=HOE(vid,width,height,length)
[w,h,l,c]=size(vid);
n_w=floor(w/width);
n_h=floor(h/height);
n_l=floor(l/length);
feature=zeros(n_w,n_h,n_l,c*8);


%% ***************************** Sum ************************************
for i=1:n_w
    for j=1:n_h
        for k=1:n_l
            local=vid((i-1)*width+1:i*width,(j-1)*height+1:j*height,(k-1)*length+1:k*length,:);
            
            count=0;
            for x=1:2
                for y=1:2
                    for z=1:2
                        templocal=local((x-1)*width/2+1:x*width/2,(y-1)*height/2+1:y*height/2,(z-1)*length/2+1:z*length/2,:);
                        feature(i,j,k,count*c+1:(count+1)*c)=sum(sum(sum(templocal)));
                        feature(i,j,k,count*c+1:(count+1)*c)=feature(i,j,k,count*c+1:(count+1)*c)./(sum(feature(i,j,k,count*c+1:(count+1)*c))+eps);
                        count=count+1;
                    end
                end
            end
        end
    end
end




end