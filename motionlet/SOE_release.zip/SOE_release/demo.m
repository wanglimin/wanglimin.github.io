% This is a demo code for spatio temporal orientation energy, dense hoe
% features, dense hog features, created by Wang Limin.
% If you have any problems, please contact 07wanglimin@gmail.com
% Reference:
% L.M. Wang, Y. Qiao, and X. Tang, Motionlets: Mid-Level 3D Part for Human
% Motion Recognition, in CVPR 2013.

 clc; clear; close;
% video data
vidObj=VideoReader('test.avi');
video=read(vidObj);
img=zeros(size(video,1),size(video,2),size(video,4));
for j=1:size(video,4)
    img(:,:,j)=im2single(rgb2gray(video(:,:,:,j)));
end

% spatio temporal orientation filter
SOE = SpatialTemporalEnergy(img,'G3',3,0);

% seperate motion energy from static and unstructure energy
structure=max(SOE(:))/100;
SOE=max(bsxfun(@minus,SOE(:,:,:,1:end-1),SOE(:,:,:,end)+structure),0);

% normalization
SOE=bsxfun(@rdivide,SOE,sum(SOE,4)+eps);

% dense HOE
hoefeature=HOE(SOE,4,4,4);
% dense HOG
[gradient_x,gradient_y] = gradient(img);
hogfeature = HOG(gradient_x,gradient_y,4,4,4,8);

% visulization
[hoeimg,hogimg] = VisualFeature(cat(4,hoefeature,hogfeature),1,20);
subplot(1,3,1)
imagesc(img(:,:,1));
axis off;
axis square;
colormap gray;
title('Video Image');

subplot(1,3,2)
imagesc(hoeimg);
axis off;
axis square;
colormap gray;
title('HOE feature');

subplot(1,3,3)
imagesc(hogimg);
axis off;
axis square;
colormap gray;
title('HOG feature');
