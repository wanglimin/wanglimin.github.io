function [H3a_img, H3b_img, H3c_img, H3d_img, H3e_img, H3f_img, H3g_img, H3h_img, H3i_img, H3j_img,H3k_img,H3l_img,H3m_img,H3n_img,H3o_img] = imgInit3DH3(img)
SAMPLING_RATE=0.5;
N=0.89448;

syms t;
f1=N*(-0.9454+2.959*t^2-0.6582*t^4)*exp(-t^2);
f2=N*(1.4795*t-0.6582*t^3)*exp(-t^2);
f3=sqrt(N)*(-sqrt(0.6582)*t^2+0.7585*sqrt(0.6582))*exp(-t^2);
f4=sqrt(N)*(sqrt(0.6582)*t^2-0.7585*sqrt(0.6582))*exp(-t^2);
f5=N*(0.493168-0.6582*t^2)*exp(-t^2);
f6=t*exp(-t^2);
f7=exp(-t^2);

i=SAMPLING_RATE*[-6:6];
filter_size=length(i);
basis=[subs(f1,t,i); subs(f2,t,i); subs(f3,t,i); subs(f4,t,i); subs(f5,t,i);subs(f6,t,i);subs(f7,t,i)];

H3a_img=imfilter(img,reshape(basis(1,:),1,filter_size),'symmetric','same','conv');
H3a_img=imfilter(H3a_img,reshape(basis(7,:),filter_size,1),'symmetric','same','conv');
H3a_img=imfilter(H3a_img,reshape(basis(7,:),1,1,filter_size),'symmetric','same','conv');

H3b_img=imfilter(img,reshape(basis(2,:),1,filter_size),'symmetric','same','conv');
H3b_img=imfilter(H3b_img,reshape(basis(6,:),filter_size,1),'symmetric','same','conv');
H3b_img=imfilter(H3b_img,reshape(basis(7,:),1,1,filter_size),'symmetric','same','conv');

H3c_img=imfilter(img,reshape(basis(3,:),1,filter_size),'symmetric','same','conv');
H3c_img=imfilter(H3c_img,reshape(basis(4,:),filter_size,1),'symmetric','same','conv');
H3c_img=imfilter(H3c_img,reshape(basis(7,:),1,1,filter_size),'symmetric','same','conv');

H3d_img=imfilter(img,reshape(basis(6,:),1,filter_size),'symmetric','same','conv');
H3d_img=imfilter(H3d_img,reshape(basis(2,:),filter_size,1),'symmetric','same','conv');
H3d_img=imfilter(H3d_img,reshape(basis(7,:),1,1,filter_size),'symmetric','same','conv');

H3e_img=imfilter(img,reshape(basis(7,:),1,filter_size),'symmetric','same','conv');
H3e_img=imfilter(H3e_img,reshape(basis(1,:),filter_size,1),'symmetric','same','conv');
H3e_img=imfilter(H3e_img,reshape(basis(7,:),1,1,filter_size),'symmetric','same','conv');

H3f_img=imfilter(img,reshape(basis(2,:),1,filter_size),'symmetric','same','conv');
H3f_img=imfilter(H3f_img,reshape(basis(7,:),filter_size,1),'symmetric','same','conv');
H3f_img=imfilter(H3f_img,reshape(basis(6,:),1,1,filter_size),'symmetric','same','conv');

H3g_img=imfilter(img,reshape(basis(5,:),1,filter_size),'symmetric','same','conv');
H3g_img=imfilter(H3g_img,reshape(basis(6,:),filter_size,1),'symmetric','same','conv');
H3g_img=imfilter(H3g_img,reshape(basis(6,:),1,1,filter_size),'symmetric','same','conv');

H3h_img=imfilter(img,reshape(basis(6,:),1,filter_size),'symmetric','same','conv');
H3h_img=imfilter(H3h_img,reshape(basis(5,:),filter_size,1),'symmetric','same','conv');
H3h_img=imfilter(H3h_img,reshape(basis(6,:),1,1,filter_size),'symmetric','same','conv');

H3i_img=imfilter(img,reshape(basis(7,:),1,filter_size),'symmetric','same','conv');
H3i_img=imfilter(H3i_img,reshape(basis(2,:),filter_size,1),'symmetric','same','conv');
H3i_img=imfilter(H3i_img,reshape(basis(6,:),1,1,filter_size),'symmetric','same','conv');

H3j_img=imfilter(img,reshape(basis(3,:),1,filter_size),'symmetric','same','conv');
H3j_img=imfilter(H3j_img,reshape(basis(7,:),filter_size,1),'symmetric','same','conv');
H3j_img=imfilter(H3j_img,reshape(basis(4,:),1,1,filter_size),'symmetric','same','conv');

H3k_img=imfilter(img,reshape(basis(6,:),1,filter_size),'symmetric','same','conv');
H3k_img=imfilter(H3k_img,reshape(basis(6,:),filter_size,1),'symmetric','same','conv');
H3k_img=imfilter(H3k_img,reshape(basis(5,:),1,1,filter_size),'symmetric','same','conv');

H3l_img=imfilter(img,reshape(basis(7,:),1,filter_size),'symmetric','same','conv');
H3l_img=imfilter(H3l_img,reshape(basis(3,:),filter_size,1),'symmetric','same','conv');
H3l_img=imfilter(H3l_img,reshape(basis(4,:),1,1,filter_size),'symmetric','same','conv');


H3m_img=imfilter(img,reshape(basis(6,:),1,filter_size),'symmetric','same','conv');
H3m_img=imfilter(H3m_img,reshape(basis(7,:),filter_size,1),'symmetric','same','conv');
H3m_img=imfilter(H3m_img,reshape(basis(2,:),1,1,filter_size),'symmetric','same','conv');

H3n_img=imfilter(img,reshape(basis(7,:),1,filter_size),'symmetric','same','conv');
H3n_img=imfilter(H3n_img,reshape(basis(6,:),filter_size,1),'symmetric','same','conv');
H3n_img=imfilter(H3n_img,reshape(basis(2,:),1,1,filter_size),'symmetric','same','conv');

H3o_img=imfilter(img,reshape(basis(7,:),1,filter_size),'symmetric','same','conv');
H3o_img=imfilter(H3o_img,reshape(basis(7,:),filter_size,1),'symmetric','same','conv');
H3o_img=imfilter(H3o_img,reshape(basis(1,:),1,1,filter_size),'symmetric','same','conv');