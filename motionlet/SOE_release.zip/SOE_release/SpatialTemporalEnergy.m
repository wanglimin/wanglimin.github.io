function [totalVid]=SpatialTemporalEnergy(vid,filter,orientation,hilbert)
if nargin<2
    filter='G3';
    orientation=3;
    hilbert=0;
end

if nargin<3
    orientation=3;
    hilbert=0;
end

if nargin<4
    hilbert=0;
end

e_axis=[0,1,0];

%% ****************************** Orientation Assignment *********************************

switch orientation
    case 1 % 4-neighboor
        temp=[1,0;-1,0;0,1;0,-1];
        direction=zeros(5,3);
        for i=1:4
            direction(i,:)=[temp(i,:),1];
            direction(i,:)=direction(i,:)./sqrt(sum(direction(i,:).^2));
        end
        direction(end,:)=[0,0,1];
    case 2 % 4-neighboor with 3 speeds
        temp=[1,0;-1,0;0,1;0,-1];
        direction=zeros(13,3);
        count=1;
        for i=1:4
            direction(count,:)=[temp(i,:),1];
            direction(count,:)=direction(count,:)./sqrt(sum(direction(count,:).^2));
            count=count+1;
            direction(count,:)=[0.5*temp(i,:),1];
            direction(count,:)=direction(count,:)./sqrt(sum(direction(count,:).^2));
            count=count+1;
            direction(count,:)=[2*temp(i,:),1];
            direction(count,:)=direction(count,:)./sqrt(sum(direction(count,:).^2));
            count=count+1;
        end
        direction(end,:)=[0,0,1];
    case 3  % 8-neighboor
        temp=[1,0;1,-1;0,-1;-1,-1;-1,0;-1,1;0,1;1,1];
        direction=zeros(9,3);
        for i=1:8
            direction(i,:)=[temp(i,:),1];
            direction(i,:)=direction(i,:)./sqrt(sum(direction(i,:).^2));
        end
        direction(end,:)=[0,0,1];
    case 4 % 8-neighboor with 3 speeds
        temp=[1,0;-1,0;0,1;0,-1;1,1;1,-1;-1,1;-1,-1];
        direction=zeros(25,3);
        count=1;
        for i=1:8
            direction(count,:)=[temp(i,:),1];
            direction(count,:)=direction(count,:)./sqrt(sum(direction(count,:).^2));
            count=count+1;
            direction(count,:)=[0.5*temp(i,:),1];
            direction(count,:)=direction(count,:)./sqrt(sum(direction(count,:).^2));
            count=count+1;
            direction(count,:)=[2*temp(i,:),1];
            direction(count,:)=direction(count,:)./sqrt(sum(direction(count,:).^2));
            count=count+1;
        end
        direction(end,:)=[0,0,1];
end

number=size(direction,1);


%% ******************************** Spatial temproal filter ****************************************

[w,h,l]=size(vid);
totalVid=zeros(w,h,l,number);

switch filter
    case 'G2'
        [G2a_img, G2b_img, G2c_img, G2d_img, G2e_img, G2f_img] = imgInit3DG2(vid);
        for i=1:number
            for j=0:2
                tempdirection=getDirection(direction(i,:),e_axis,j,2);
                G2_steered = imgSteer3DG2(tempdirection, G2a_img, G2b_img, G2c_img, G2d_img, G2e_img, G2f_img);
                %tempenergy=smooth3(G2_steered.^2,'gaussian');
                tempenergy=G2_steered.^2;
                totalVid(:,:,:,i)=totalVid(:,:,:,i)+tempenergy;
            end
        end
        
        if hilbert==1
            [H2a_img, H2b_img, H2c_img, H2d_img, H2e_img, H2f_img, H2g_img, H2h_img, H2i_img, H2j_img] = imgInit3DH2(vid);
            for i=1:number
               for j=0:2
                   tempdirection=getDirection(direction(i,:),e_axis,j,2);
                   H2_steered = imgSteer3DH2(tempdirection, H2a_img, H2b_img, H2c_img, H2d_img, H2e_img, H2f_img, H2g_img, H2h_img, H2i_img, H2j_img);
                   %tempenergy=smooth3(H2_steered.^2,'gaussian');
                   tempenergy=H2_steered.^2;
                   totalVid(:,:,:,i)=totalVid(:,:,:,i)+tempenergy;
               end
            end
        end
    case 'G3'
        [G3a_img, G3b_img, G3c_img, G3d_img, G3e_img, G3f_img, G3g_img, G3h_img, G3i_img, G3j_img] = imgInit3DG3(vid);
        for i=1:number
            for j=0:3
                tempdirection=getDirection(direction(i,:),e_axis,j,3);
                G3_steered=imgSteer3DG3(tempdirection,G3a_img, G3b_img, G3c_img, G3d_img, G3e_img, G3f_img, G3g_img, G3h_img, G3i_img, G3j_img);
                %tempenergy=smooth3(G3_steered.^2,'gaussian',[5,5,5],1.0);
                totalVid(:,:,:,i)=totalVid(:,:,:,i)+G3_steered.^2;
            end
        end
        if hilbert==1
            [H3a_img, H3b_img, H3c_img, H3d_img, H3e_img, H3f_img, H3g_img, H3h_img, H3i_img, H3j_img,H3k_img,H3l_img,H3m_img,H3n_img,H3o_img] = imgInit3DH3(vid);
            for i=1:number
                for j=0:3
                    tempdirection=getDirection(direction(i,:),e_axis,j,3);
                    H3_steered=imgSteer3DH3(tempdirection, H3a_img, H3b_img, H3c_img, H3d_img, H3e_img, H3f_img, H3g_img, H3h_img, H3i_img, H3j_img,H3k_img,H3l_img,H3m_img,H3n_img,H3o_img);
                    % tempenergy=smooth3(H3_steered.^2,'gaussian');
                    tempenergy=H3_steered.^2;
                    totalVid(:,:,:,i)=totalVid(:,:,:,i)+tempenergy;
                end
            end
        end

    otherwise
        warning('Unrecognized Filter');
        
end

end

