% IMGSTEER3DH2
%    
%   Steer 3D H2 filter to direction DIRECTION (unit vector) using basis
%   images H2A_IMG, ..., H2J_IMG, computed using IMGINIT3DH2.
%
%   References (available at www.cs.yorku.ca/~kosta): 
%     1. Derpanis, K.G, and Gryn J.M., Three-Dimensional nth Derivative of 
%          Gaussian Separable Steerable Filters, ICIP, 2005
%
%     2. Derpanis, K.G, and Gryn J.M., Three-Dimensional nth Derivative of 
%          Gaussian Separable Steerable Filters, Technical Report CS-2004-05, 
%          York University
%
%   Disclaimer: Note that while great care has been taken, the software, code
%               and data are provided "as is" and that the author does not 
%               accept any responsibility or liability.
%
% Coded By: Konstatinos G. Derpanis
% Last Updated: April 17, 2006.
function [img] = imgSteer3DH2(direction, H2a_img, H2b_img, H2c_img, H2d_img, H2e_img, H2f_img, H2g_img, H2h_img, H2i_img, H2j_img)

a = direction(1);
b = direction(2);
c = direction(3);

img = (a^3)*H2a_img ...
    + 3*(a^2)*b*H2b_img ... 
    + 3*a*(b^2)*H2c_img ...
    + (b^3)*H2d_img ...
    + 3*(a^2)*c*H2e_img ...
    + 6*a*b*c*H2f_img ...
    + 3*(b^2)*c*H2g_img ...
    + 3*a*(c^2)*H2h_img ...
    + 3*b*(c^2)*H2i_img ...
    + (c^3)*H2j_img;
    